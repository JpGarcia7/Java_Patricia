package exercicio2;

import java.util.Scanner;

import listas.listaAluno;

public class planilhaAluno {
	
	public static void main(String[] args) {
		listaAluno turma = new listaAluno();
		Scanner le = new Scanner(System.in);
		
		int opcao;
		
		do {
			System.out.println("0 - Sair");
			System.out.println("1 - Inserir Aluno");
			System.out.println("2 - Remover aluno");
			System.out.println("Op��o: ");
			opcao = le.nextInt();
			switch (opcao) {
			case 0:
				System.out.println("Programa Encerrado");
				break;
			case 1:
				System.out.println("Informe Rm do aluno que sera inserio");
				int rm = le.nextInt();
				System.out.println("Media");
				double media = le.nextDouble();
				Aluno aluno = new Aluno(rm, media);
				turma.insere(aluno);
				turma.show();
				break;
			case 2:
				System.out.println("Informe Rm do aluno que ser� removido: ");
				rm = le.nextInt();
				turma.remove(rm);
				turma.show();
				break;
			case 3:
				System.out.println("Informe Rm do aluno sera pesquisado");
				rm = le.nextInt();
				double m = turma.select(rm);
				if (m == -1)
					System.out.println("Aluno n�o encontrado");
				else
					System.out.println("A media �" + rm);
				default:
					System.out.println("Op��o invalido");
			}
		}while (opcao !=0);
		le.close();
	}

}
