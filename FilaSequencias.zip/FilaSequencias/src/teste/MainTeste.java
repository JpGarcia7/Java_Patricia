package teste;

import filaSequencias.filaSequenciasInt;

public class MainTeste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		filaSequenciasInt fila = new filaSequenciasInt();
		fila.init();
		
		fila.enqueue(23);
		fila.enqueue(17);
		fila.enqueue(66);
		
		if (!fila.isEmpty())
		System.out.println("Valor retirado:" +fila.dequeue());
		if (!fila.isEmpty())
		System.out.println("Valor retirado:" +fila.dequeue());
		if (!fila.isEmpty())
		System.out.println("Valor retirado:" +fila.dequeue());

	}

}
